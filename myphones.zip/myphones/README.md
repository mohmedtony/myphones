CS50-Final-Project
my name is mohmed tony ,i live in egypt
YourLists: A Shopping store and Todo List Web App
A CS50 Final Project
Made as a final project for the course CS50's Introduction to Computer Science, Your store helps users manage their shopping lists as well as todo lists
usage
If someone one day preferred to buy an iPhone, this site will give him all the necessary information about the product, whether the size or the RAM, as well as the price. This site also contains different colors
There is also customer service and information on the page
Also the languages used to build this project
css
html
javascript
also using xampp
this vedio
https://www.youtube.com/watch?v=ZWUrzzUtj0c&ab_channel=MohmedTony